<?xml version="1.0" encoding="UTF-8"?>
<tileset version="0" tiledversion="1.8.5" name="RollingSky" tilewidth="64" tileheight="64" tilecount="2048" columns="32">
 <image source="tileset01.png" width="2048" height="4096"/>
</tileset>
